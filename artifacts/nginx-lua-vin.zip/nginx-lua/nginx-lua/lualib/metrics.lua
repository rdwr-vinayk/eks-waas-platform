-- Metrics
-- Collect EAD run time metrics, and expose an json object
local _M = {
    VERSION = "0.1",
    metric_names = {
        Initialized = {name="initialized", t="internal"},
    },
    stream_metric_names = {
        Initialized = {name="initialized", t="internal"},
        -- MetricUsageError is increment when there is an error using the metrics API.
        MetricUsageError = {name="sfdc.ead.lua.metrics_error", t="counter"},
        -- Max HTTP request response time is 30 minutes
        WAFRequestHandlingTime = {name="sfdc.ead.lua.waf.request.handling.time", t="hist", buckets={0, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 1000000, 2000000}},
        -- We have only request code until 10, keeping additional bucket to capture new updates
        WAFRequestHandlingCode = {name="sfdc.ead.lua.waf.request.handling.code", t="hist", buckets={0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 20, 21, 22, 23, 100}},
        WAFRequestCount = {name="sfdc.ead.lua.waf.request.count", t="counter"},
        WAFRequestSuccess = {name="sfdc.ead.lua.waf.request.success", t="counter"},
        WAFRequestForbidden = {name="sfdc.ead.lua.waf.request.forbidden", t="counter"},
        WAFRequestFailure = {name="sfdc.ead.lua.waf.request.failure", t="counter"},
        WAFRequestFailCloseDrop = {name="sfdc.ead.lua.waf.request.fail.close.drop", t="counter"},
        WAFRequestTransferEncodingCount = {name="sfdc.ead.lua.waf.request.transfer.encoding.count", t="counter"},
        WAFConcurrentRequestEdge = {name="sfdc.ead.lua.waf.request.concurrent.main", t="counter"},
        WAFConcurrentRequestEnforcer = {name="sfdc.ead.lua.waf.request.concurrent.enforcer", t="counter"},
        WAFDownstreamConnectError = {name="sfdc.ead.lua.waf.downstream.connect.error", t="counter"},
        WAFDownstreamReadError = {name="sfdc.ead.lua.waf.downstream.read.error", t="counter"},
        WAFDownstreamRegexError = {name="sfdc.ead.lua.waf.downstream.regex.error", t="counter"},
        WAFDownstreamParseError = {name="sfdc.ead.lua.waf.downstream.parse.error", t="counter"},
        WAFDownstreamInvalidRequest = {name="sfdc.ead.lua.waf.downstream.invalid.request", t="counter"},
        WAFDownstreamBodyError = {name="sfdc.ead.lua.waf.downstream.body.error", t="counter"},
        WAFDownstreamResponseError = {name="sfdc.ead.lua.waf.downstream.response.error", t="counter"},
        WAFDownstreamResponseOutfilterUnreadError = {name="sfdc.ead.lua.waf.downstream.response.outfilter.unread.error", t="counter"},
        WAFDownstreamResponseOutfilterDefaultError = {name="sfdc.ead.lua.waf.downstream.response.outfilter.default.error", t="counter"},
        WAFUpstreamConnectError = {name="sfdc.ead.lua.waf.upstream.connect.error", t="counter"},
        WAFUpstreamRequestSendPipeError = {name="sfdc.ead.lua.waf.upstream.request.send.pipe.error", t="counter"},
        WAFUpstreamResponseReadChunkError = {name="sfdc.ead.lua.waf.upstream.response.read.chunk.error", t="counter"},
        WAFUpstreamResponseReadHTTPVersionError = {name="sfdc.ead.lua.waf.upstream.response.http.version.error", t="counter"},
        WAFUpstreamResponseError = {name="sfdc.ead.lua.waf.upstream.response.error", t="counter"},
        WAFEnforcerHandlingTime = {name="sfdc.ead.lua.waf.enforcer.handling.time", t="hist", buckets={0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 50, 100, 200, 500, 1000}},
        WAFEnforcerHandlingCode = {name="sfdc.ead.lua.waf.enforcer.handling.code", t="hist", buckets={0, 10, 12, 199, 200, 402, 403, 405, 406, 499, 500, 501, 502, 503, 600}},
        WAFEnforcerErrorConnect = {name="sfdc.ead.lua.waf.enforcer.error.connect", t="counter"},
        WAFEnforcerErrorRead = {name="sfdc.ead.lua.waf.enforcer.error.read", t="counter"},
        WAFBackoffTriggerLock = {name="sfdc.ead.lua.waf.backoff.trigger.lock", t="internal"},
        WAFBackoffTriggerIndicatorKey = {name="sfdc.ead.lua.waf.backoff.trigger.indicator", t="internal"},
        WAFBackoffRequestSuccess = {name="sfdc.ead.lua.waf.backoff.request.success", t="counter"},
        WAFBackoffRequestFailure = {name="sfdc.ead.lua.waf.backoff.request.failure", t="counter"},
        WAFBackoffLockAcquireSuccess = {name="sfdc.ead.lua.waf.backoff.lock.acquire.success", t="counter"},
        WAFBackoffLockAcquireFailure = {name="sfdc.ead.lua.waf.backoff.lock.acquire.failure", t="counter"},
        WAFBackoffTriggerApprovals = {name="sfdc.ead.lua.waf.backoff.trigger.approvals", t="counter"},
        WAFBackoffAlreadyTriggerdDenials = {name="sfdc.ead.lua.waf.backoff.already.triggered.denials", t="counter"},
        WAFBackoffAlreadyTriggerdDisable = {name="sfdc.ead.lua.waf.backoff.already.triggered.disable", t="counter"},
        WAFBackoffTriggerDenialsDueToThreshold = {name="sfdc.ead.lua.waf.backoff.trigger.threshold.denials", t="counter"},
        WAFBackoffInternalError = {name="sfdc.ead.lua.waf.backoff.internal.error", t="counter"},
        WAFBackoffBackoffSkippedCode = {name="sfdc.ead.lua.waf.backoff.skipped.code", t="hist", buckets={1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 21, 22, 23}},
        WAFAccessRotateLock = {name="sfdc.ead.lua.waf.stream.access.rotate.lock", t="internal"},
        WAFAccessInternalError = {name="sfdc.ead.lua.waf.access.internal.error", t="counter"},
        WAFAccessLogDropError = {name="sfdc.ead.lua.waf.access.log.drop.error", t="counter"},
    }
}

-- new
-- Create a new metrics object.  This should be run first from
-- init_by_lua so that we can initialize all the counters to zero,
-- and be loaded into the memory of the master process to be shared
-- with the worker nodes during worker forking.
function _M.new(args)
    local opts = args or {}
    return setmetatable({ opts = opts }, { __index = _M })
end

-- initialize the metrics object for particular context
function _M.init(self, stream_context, forced_reset)
end

-- decrement the counter of the metric by one.
function _M:decrement(metric)
end

-- increment the counter of the metric by one.
function _M:increment(metric)
end

-- sets current metric counter value: useful for mock testing and value update
function _M:update(metric, value)
end

-- resets current metric counter value: useful for mock testing
function _M:reset(metric)
end

-- get current metric counter value: useful for mock testing
function _M:read(metric)
end


-- buckets are assumed to be in increasing order
function _M:capture_time(metric, observed_time)
end

-- copy_metrics returns a copy of the metrics.
-- Useful when for dumping the metrics in a way that does
-- no interfere with metrics gathering.
function _M:copy_metrics()
    return {}
end


return _M.new(nil)
