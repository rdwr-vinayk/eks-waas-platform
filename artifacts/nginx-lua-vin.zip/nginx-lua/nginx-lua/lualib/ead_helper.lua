local M = {}

M.standard_headers = {
    transfer_encoding = "Transfer-Encoding",
    proxy_authorization = "Proxy-Authorization",
    content_length = "Content-Length",
    host = "Host",
    user_agent = "User-Agent",
    connection = "Connection",
    expect = "Expect",
    trailer = "Trailer",
    request_id = "X-Request-Id",
    server_timing = "Server-Timing",
    upstream_cell = 'X-Upstream'
}

M.const_strings = {
    space_separator = "%s",
    comma_separator = ",",
    asterisk_character = "*",
}

function M.split_str (inputstr, sep)
    if sep == nil then
        sep = "%s"
    end
    local t={}
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        str = str:gsub("%s+", "")
        table.insert(t, str)
    end
    return t
end

function M.validate_bsc_string(backoff_skip_codes_string)
    return true
end

return M
