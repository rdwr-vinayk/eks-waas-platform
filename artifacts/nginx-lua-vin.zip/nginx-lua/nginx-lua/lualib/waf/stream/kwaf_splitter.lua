-- Copyright (c) Radware Ltd..
-- All rights reserved.

local fifo_new = require "waf.stream.kwaf_fifo"
local setmetatable = setmetatable
local tbl_concat = table.concat
local ngx_sleep = ngx.sleep

local splitter = {
    _VERSION = '1.19.0',
}
local mt = { __index = splitter }

local function yield(yield_time)
    ngx_sleep(yield_time)
end

function splitter.new(opts)
    local kwaf_fifo = fifo_new()
    local upstream_fifo = fifo_new()
    local kwaf_yield_time = 0
    local upstream_yield_time = 0

    local shadow = opts.shadow or false
    if shadow then
        kwaf_yield_time = opts.kwaf_yield_time or 0
        -- to milliseconds when value is greater than 0 since the input value is in milliseconds
        -- but the ngx.sleep accepts seconds with time resolution up to 0.001 seconds
        if kwaf_yield_time > 0 then
            kwaf_yield_time = kwaf_yield_time/1000
        end

        upstream_yield_time = opts.upstream_yield_time or 0
        -- to milliseconds when value is greater than 0 since the input value is in milliseconds
        -- but the ngx.sleep accepts seconds with time resolution up to 0.001 seconds
        if upstream_yield_time > 0 then
            upstream_yield_time = upstream_yield_time/1000
        end
    end

    return setmetatable({
        reader = opts.reader,
        max_chunk_size = opts.max_chunk_size,
        kwaf_max_read_bytes = opts.kwaf_max_read_bytes,
        shadow = shadow,
        kwaf_yield_time = kwaf_yield_time,
        upstream_yield_time = upstream_yield_time,
        kwaf_need_read = true,
        upstream_need_read = true,
        kwaf_fifo = kwaf_fifo,
        upstream_fifo = upstream_fifo,
    }, mt)
end

local function _flush_fifo (fifo)
    local length = fifo:length()
    local ret_data = nil
    local any_err = nil
    while length > 0 do
        local val = fifo:pop()
        if val.err then
            if any_err then
                any_err = any_err .. " error: " .. val.err
            else
                any_err = "error: " .. val.err
            end
        end
        if val.data then
            if ret_data then
                ret_data = tbl_concat({ret_data, val.data})
            else
                ret_data = val.data
            end
        end
        length = length - 1
    end
    return ret_data, any_err
end

local function _read_split(self, max_chunk_size)
    if self.upstream_need_read or self.kwaf_need_read then
        -- ngx.log(ngx.WARN, "_read_split: upstream_need_read = " .. tostring(self.upstream_need_read) .. " kwaf_need_read = " .. tostring(self.kwaf_need_read))
        local to_read = 0
        to_read = self.kwaf_max_read_bytes - (self.kwaf_fifo.total_returned_byte_size + self.kwaf_fifo.current_byte_size)
        local chunk_size = max_chunk_size or self.max_chunk_size;
        if (to_read > 0) and (to_read < chunk_size) then
            chunk_size = to_read
        elseif to_read <= 0 then
            self.kwaf_need_read = false
        end
        local data, err = self.reader(chunk_size)
        if data then
            local size = #data
            self.upstream_fifo:push({data = data, err = err, size = size})
            if self.kwaf_need_read then
                self.kwaf_fifo:push({data = data, err = err, size = size})
            end
            return data, err, size, chunk_size
        elseif err then
            -- may get it due to corouting function done, data = nil
            if err ~= "running" then
                self.kwaf_need_read = false
                self.upstream_need_read = false
            end
            return nil, err, 0, chunk_size
        else -- all values returned are nil
            self.kwaf_need_read = false
            self.upstream_need_read = false
            return nil, nil, 0, chunk_size
        end
    end
    return nil, nil, 0, 0
end

function splitter:kwaf_reader()
    return function(max_chunk_size)
        repeat
            local data, err, size, chunk_size = _read_split(self, max_chunk_size)
            -- ngx.log(ngx.WARN, "kwaf_reader: size = " .. size .. " chunk_size = " .. chunk_size .. " err = " .. tostring(err))
            if err and err == "running" then
                yield(self.kwaf_yield_time)
            end
        until data or not err or err ~= "running"

        local all_data, any_err = _flush_fifo(self.kwaf_fifo)
        -- ngx_sleep(0)  -- Edge disable it avoid additional latency
        return all_data, any_err
    end
end

function splitter:upstream_reader()
    return function(max_chunk_size)
        repeat
            local data, err, size, chunk_size = _read_split(self, max_chunk_size)
            -- ngx.log(ngx.WARN, "upstream_reader: size = " .. size .. " chunk_size = " .. chunk_size .. " err = " .. tostring(err))
            if err and err == "running" then
                yield(self.upstream_yield_time)
            end
        until data or not err or err ~= "running"

        local all_data, any_err = _flush_fifo(self.upstream_fifo)
        -- ngx_sleep(0)  -- Edge disable it avoid additional latency
        return all_data, any_err
    end
end

return splitter
