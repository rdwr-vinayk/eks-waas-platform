-- Copyright (c) Radware Ltd.
-- All rights reserved.

local ngx = ngx
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR
local ngx_DEBUG = ngx.DEBUG
local yield = coroutine.yield
local str_find = string.find
local DEBUG = false

local function traceback ()
	local level = 1
	local str_trace = " "
	while true do
		local info = debug.getinfo(level, "Snl")
		if not info then break end
		if info.what == "C" then   -- is a C function?
			str_trace = str_trace .. string.format("{%d: C function}", level)
		else   -- a Lua function
			str_trace = str_trace .. string.format("{%d: [%s]: %d: %s}", level, info.short_src, info.currentline, info.name)
		end
		level = level + 1
	end
	return str_trace
end

local function log(msg, log_level)
	if DEBUG then
		local str_trace = traceback()
		if not log_level then
			log_level = ngx_ERR
		end
		ngx_log(log_level, msg, str_trace)
	end
end

local _M = {}
_M._VERSION = "1.19"

local mt = { __index = _M }

local _ROLE_DOWNSTREAM = "DOWN"
local _ROLE_UPSTREAM = "UP"
local _DEFAULT_TIMEOUT = 20
-- it is recommended that wait_time * wait_count > timeout
local _DEFAULT_CLOSE_WAIT_TIME = 1
local _DEFAULT_CLOSE_WAIT_COUNT = 20
local _DEFAULT_MAX_RECV_SIZE = 1000

function _M.debug()
	DEBUG = true
end

function _M.new()
	return setmetatable({
		is_closing = false,
	}, mt)
end

function _M.set_closing_state(self)
	self.is_closing = true
end

local function is_timeout(err_msg)
	if str_find(err_msg, "timeout", 1, true) then
		return true
	end
	return false
end

local function is_closing(err_msg)
	if str_find(err_msg, "closed", 1, true) then
		return true
	end
	return false
end

function _M.forward(self, role, sock_from, sock_to, max_recv_size)
	local max_size = max_recv_size or _DEFAULT_MAX_RECV_SIZE
	while true do
		if self.is_closing then
			log(role .. " is closing",ngx_DEBUG)
			return
		end
		-- receive data from socket
		local data, err = sock_from:receiveany(max_size)
		if not data then
			if is_timeout(err) then
				-- log(role .. " RECV timeout, retrying",ngx_DEBUG)
				-- continue
			elseif is_closing(err) then
				log(role .. " calling set_closing_state",ngx_DEBUG)
				self:set_closing_state()
				return role
			else
				log(role .. " RECV error: " .. tostring(err), true)
				return role, err
			end
		else
			log(role .. " RECV, got data. len: " .. tostring(#data),ngx_DEBUG)
		end
		if data and not self.is_closing then
			local bytes, err = sock_to:send(data)
			if err then
				log(role .. " SEND error:" .. tostring(err))
				self:set_closing_state()
				return role, err
			else
				log(role .. " SEND, total " .. tostring(bytes) .. " bytes",ngx_DEBUG)
			end
		end
		yield(self)
	end
end

local function kill_wait_coroutine(co_routine)
	--  give other thread a chance to finish
	--  so that last message send by other thread gets there
	local wait_count, wait_time
	wait_count = 10
	wait_time = 1
	while wait_count > 0 do
		local co_status = coroutine.status(co_routine)
		if co_status ~= "dead" then
			log(
				"waiting " .. tostring(wait_time) .. "ms on server to finish. " .. tostring(wait_count) .. " more times",ngx_DEBUG
			)
			ngx.sleep(0.001 * wait_time)
		else
			break
		end
		wait_count = wait_count - 1
	end
	log("server is done (or we are done waiting), terminating",ngx_DEBUG)
	ngx.thread.kill(co_routine)
end

--- initiate peers and start proxying back and forth
--- @param downstream_socket any the downstream ngx.tcp.socket
--- @param upstream_socket any the upstream ngx.tcp.socket
function _M.proxy(self, downstream_socket, upstream_socket, opts)
	local timeout, max_recv_size, close_wait_count, close_wait_time
	if opts then
		timeout = opts.timeout
		max_recv_size = opts.max_recv_size
		close_wait_count = opts.close_wait_count
		close_wait_time = opts.close_wait_time
	end
	timeout = timeout or _DEFAULT_TIMEOUT
	max_recv_size = max_recv_size or _DEFAULT_MAX_RECV_SIZE
	close_wait_count = close_wait_count or _DEFAULT_CLOSE_WAIT_COUNT
	close_wait_time = close_wait_time or _DEFAULT_CLOSE_WAIT_TIME

	-- set timeouts
	downstream_socket:settimeout(timeout)
	upstream_socket:settimeout(timeout)

	local downstream_co =
		ngx.thread.spawn(self.forward, self, _ROLE_DOWNSTREAM, downstream_socket, upstream_socket, max_recv_size)
	local upstream_co =
		ngx.thread.spawn(self.forward, self, _ROLE_UPSTREAM, upstream_socket, downstream_socket, max_recv_size)

	local ok, res, err = ngx.thread.wait(downstream_co, upstream_co)
	log("wait returned. ok=" .. tostring(ok) .. " res=" .. tostring(res) .. " err=" .. tostring(err),ngx_DEBUG)
	local finished_co = res

	log(finished_co .. " thread terminated. terminating other thread. (err = " .. tostring(err) .. ")",ngx_DEBUG)
	if finished_co == _ROLE_DOWNSTREAM then
		-- downstream socket is readonly, can't close
		local ok, err = upstream_socket:close()
		if not ok then
			log("could not close upstream socket. " .. err)
		else
			log("upstream socket closed successfully",ngx_DEBUG)
		end
		kill_wait_coroutine(downstream_co)
	else
		kill_wait_coroutine(upstream_co)
	end
end

return _M
