-- Supports access log writing in json format

local _M = {
    VERSION = '0.1',
}

_M.init = function(opts)
    -- Truncated salesforce code
end

_M.log = function(request_table)
    -- Truncated salesforce code
end

return _M