---@diagnostic disable: need-check-nil
-- Copyright (c) Radware Ltd..
-- All rights reserved.

local ngx = ngx
local ngx_var = ngx.var
local ngx_req = ngx.req
local ngx_req_socket = ngx_req.socket
local ngx_OK = ngx.OK
local ngx_exit = ngx.exit
local ngx_thread = ngx.thread
local ngx_thread_spawn = ngx_thread.spawn
local ngx_say = ngx.say
local ngx_flush = ngx.flush

local splitter = require "waf.stream.kwaf_splitter"
local http = require "waf.stream.kwaf_http"
local kwaf_http_headers = require "waf.stream.kwaf_http_headers"
local tcpproxy = require "waf.stream.kwaf_tcp_proxy"
local handler = require "waf.stream.kwaf_ead_handler"
local alogger = require "waf.stream.kwaf_ead_access_log"
local elogger = require "ead_logger"
local metrics = require "metrics"
local helpers = require "ead_helper"

local standard_headers = helpers.standard_headers

--- response status code indicating that the server accepts upgrading to a different protocol
local _SWITCHING_PROTOCOLS_STATUS_CODE = 101
local _WEBSOCKETS_ALT_HEADER = { name = "x-kwaf-was-websockets", value = "true" }
local _WEBSOCKETS_CONN_HEADER = { name = "connection", value = "upgrade" }
local _WEBSOCKETS_UPG_HEADER = { name = "upgrade", value = "websocket" }

local _M = {
    _VERSION = '1.23.0',
}
local mt = { __index = _M }

_M.waf_config = {
    debug = false,
    min_log_level = ngx.INFO,
    kwaf_fail_close = false,
    should_keepalive_downstream_conn = false,
    chunk_size = 4 * 1024,
    partial_header_name = "x-envoy-auth-partial-body",
    original_content_length_header_name = "x-enforcer-original-content-length",
    max_req_bytes = 10 * 1024,
    lua_backlog = 100,
    lua_pool_size = 1000,
    lua_keepalive_timeout = 60 * 1000,  -- in milliseconds
    backoff_report_url = "unix:/cfgs/rptc/waf/writer.sock",
    backoff_skip_codes = {},
    backoff_trigger_threshold = 0,

    enforcer_interaction_disable = false,  -- useful for debugging
    enforcer_service_address = "127.0.0.1",
    enforcer_service_port = 9000,
    enforcer_connect_time = 5,
    enforcer_send_time = 10,
    enforcer_read_time = 10,
    enforcer_keepalive_time = 300000,
    enforcer_pool_size = 1000,
    enforcer_backlog_size = 1000,

    inspection_fail_error_code = 406,
    inspection_fail_reason = "CustomNotAcceptable",

    access_log_path = "/tmp/waf-stream-access.log",
    access_flush_interval = 10,
    access_log_size = 500000000,
    access_log_enable = true,

    content_length_gate = false,
}

_M.WAF_REQUEST_STATUS = {
    SUCCESS = 0,
    DOWNSTREAM_SOCK_CONNECT_FAILURE = 1,
    DOWNSTREAM_SOCK_READ_FAILURE = 2,
    DOWNSTREAM_HEADER_READ_FAILURE = 3,
    DOWNSTREAM_HEADER_CHUNK_INVALID = 4,
    DOWNSTREAM_BODY_READ_FAILURE = 5,
    WAF_REQUEST_FORBIDDEN = 6,
    WAF_REQUEST_FAIL_CLOSE_DROP = 7,
    WAF_UPSTREAM_CONNECT_ERROR = 8,
    WAF_UPSTREAM_REQUEST_ERROR = 9,
    WAF_DOWNSTREAM_RESPONSE_ERROR = 10,

    -- client close regex read error
    WAF_DOWNSTREAM_REGEX_READ_ERROR = 11,
    -- Client close causing output filter unread data error
    WAF_DOWNSTREAM_OUTPUT_FILTER_UNREAD_ERROR = 12,
    -- Client close causing output filter error
    WAF_DOWNSTREAM_OUTPUT_FILTER_DEFAULT_ERROR = 13,

    -- upstream close read response HTTP version
    WAF_UPSTREAM_CLOSE_READ_HTTP_VERSION_ERR = 21,
    -- upstream close send broken pipe
    WAF_UPSTREAM_CLOSE_SEND_BROKEN_PIPE_ERROR = 22,
    -- upstream close read chunk error
    WAF_UPSTREAM_CLOSE_READ_CHUNK_ERROR = 23,

    UNDEFINED = 99,
}

_M.KNOWN_DOWNSTREAM_ERR_MSG = {
    CLIENT_CLOSE_REGEX_READ_ERROR = {
        msg = "regex did not match start line",
        code = _M.WAF_REQUEST_STATUS.WAF_DOWNSTREAM_REGEX_READ_ERROR,
        metric = metrics.stream_metric_names.WAFDownstreamRegexError,
    },
}

_M.KNOWN_UPSTREAM_ERR_MSG = {
    {
        msg = "nginx output filter error unread data in buffer",
        code = _M.WAF_REQUEST_STATUS.WAF_DOWNSTREAM_OUTPUT_FILTER_UNREAD_ERROR,
        metric = metrics.stream_metric_names.WAFDownstreamResponseOutfilterUnreadError,
    },
    {
        msg = "nginx output filter error",
        code = _M.WAF_REQUEST_STATUS.WAF_DOWNSTREAM_OUTPUT_FILTER_DEFAULT_ERROR,
        metric = metrics.stream_metric_names.WAFDownstreamResponseOutfilterDefaultError,
    },
    {
        msg = "read_response: couldn't parse HTTP version",
        code = _M.WAF_REQUEST_STATUS.WAF_UPSTREAM_CLOSE_READ_HTTP_VERSION_ERR,
        metric = metrics.stream_metric_names.WAFUpstreamResponseReadHTTPVersionError,
    },
    {
        msg = "upstream response: send_request: error = broken pipe",
        code = _M.WAF_REQUEST_STATUS.WAF_UPSTREAM_CLOSE_SEND_BROKEN_PIPE_ERROR,
        metric = metrics.stream_metric_names.WAFUpstreamRequestSendPipeError,
    },
    {
        msg = "stream_proxy_response read body_chunk: closed",
        code = _M.WAF_REQUEST_STATUS.WAF_UPSTREAM_CLOSE_READ_CHUNK_ERROR,
        metric = metrics.stream_metric_names.WAFUpstreamResponseReadChunkError,
    },
}

local function traceback ()
    local level = 1
    local str_trace = " "
    while true do
        local info = debug.getinfo(level, "Snl")
        if not info then break end
        if info.what == "C" then   -- is a C function?
            str_trace = str_trace .. string.format("{%d: C function}", level)
        else   -- a Lua function
            str_trace = str_trace .. string.format("{%d: [%s]: %d: %s}", level, info.short_src, info.currentline, info.name or "no-name")
        end
        level = level + 1
    end
    return str_trace
end

local function rlog(level, id, ...)
    if level == ngx.DEBUG then
        local str_trace = traceback()
        elogger.slog("KWAF", level, _M.waf_config.min_log_level, id, str_trace, ": ", ...)
    else
        elogger.slog("KWAF", level, _M.waf_config.min_log_level, id, ...)
    end
end

local function get_time()
    ngx.update_time() -- update_time to make ngx.now() accurate
    return ngx.now() * 1000
end

_M.parse_backoff_skip_codes = function(backoff_skip_codes_string)
    return {}
end

_M.log = function(self, level, ...)
    rlog(level, self.meta.request_id, ...)
end

_M.access_log = function(self, request)
    if self.config.should_keepalive_downstream_conn then
        alogger.log(request)
    end
end

_M.reset_metadata = function(self)
    self.meta.request_id = "WORKER-"..ngx.worker.pid()
    self.meta.request_response_code = 0
    self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.UNDEFINED
    self.meta.request_start_time = get_time()
    self.meta.enforcer_response_code = 0
    self.meta.enforcer_response_time = 0
    self.meta.backoff_triggered = false
    self.meta.host_name = "-"
    self.meta.headers_size = 0
end

_M.clone_headers = function(self, headers)
    local clone_headers = kwaf_http_headers.new()
    for k, v in pairs(headers) do
        clone_headers[k] = v
        -- vague implementation of calculating header size. (sufficient for our purpose).
        -- The header size might be inaccurate by a bit due to each
        -- character in lua not being equal to exactly one byte.
        self.meta.headers_size = self.meta.headers_size + #tostring(k) + #tostring(v) + 2 -- additional 2 bytes to account for separator ":" and newline character "\n"
    end
    return clone_headers
end

_M.kwaf_headers = function(self, downstream_headers, content_length, is_chunked)
    local new_kwaf_headers = self:clone_headers(downstream_headers)
    new_kwaf_headers[self.config.original_content_length_header_name] = tostring(self.config.max_req_bytes)
    if (is_chunked) then
        -- we dont know the body size which may be  be larger than max_req_bytes. So set the partial header anyway and send max_req_bytes as the original content length
        new_kwaf_headers[self.config.partial_header_name] = "true"
        return new_kwaf_headers, self.config.max_req_bytes
    end
    if content_length <= self.config.max_req_bytes then
        return new_kwaf_headers, content_length
    end

    new_kwaf_headers[standard_headers.content_length] = tostring(self.config.max_req_bytes)
    new_kwaf_headers[self.config.original_content_length_header_name] = tostring(content_length)
    new_kwaf_headers[self.config.partial_header_name] = "true"
    return new_kwaf_headers, self.config.max_req_bytes
end

_M.trigger_backoff = function(self)
    if not self.meta.backoff_enabled then
        metrics:increment(metrics.stream_metric_names.WAFBackoffAlreadyTriggerdDisable)
        self:log(
                ngx.DEBUG,
                "Skipping backoff it is disabled for current request"
        )
        return false
    end
    if self.meta.backoff_triggered then
        -- If this request has already triggered backoff we don't need to
        -- trigger backoff againt
        metrics:increment(metrics.stream_metric_names.WAFBackoffAlreadyTriggerdDenials)
        self:log(
                ngx.DEBUG,
                "Skipping as backoff has already been marked as triggered"
        )
        return false
    end

    for _, skip_code in ipairs(self.config.backoff_skip_codes) do
        if self.meta.waf_request_status == skip_code then
            self:log(
                    ngx.DEBUG,
                    "Skipping backoff triggering, received status code: ",
                    self.meta.waf_request_status
            )
            metrics:capture_time(
                    metrics.stream_metric_names.WAFBackoffBackoffSkippedCode,
                    self.meta.waf_request_status
            )
            return false
            
        end
    end

    metrics:increment(metrics.stream_metric_names.WAFBackoffTriggerApprovals)
     local status =  handler.report_request_failure(
            self.config.backoff_report_url,
            self.meta.request_id
    )

    -- report request failure is successful if status == 0
    self.meta.backoff_triggered = status == 0 -- handler.KWAF_HANDLER_ERR.SUCCESS

    self:log(
            ngx.DEBUG,
            "Marked WAF backoff as triggered in stream context"
    )
    
    return true
end

_M.forward_request_to_enforcer = function(self, kwaf_connect_options, kwaf_request_params, shadow, kwafc)
    local ok, err, res
    local request_id = self.meta.request_id or "req-id-missing"

    metrics:increment(metrics.stream_metric_names.WAFConcurrentRequestEnforcer)
    if shadow then
        ngx.sleep(0)
    end

    local enforcer_start_time = get_time()
    ok, err = kwafc:connect(kwaf_connect_options)
    if not ok then
        rlog(
                ngx.ERR,
                request_id,
                "Failed to connect KWAF: ",
                err
        )
        metrics:increment(metrics.stream_metric_names.WAFEnforcerErrorConnect)
        metrics:decrement(metrics.stream_metric_names.WAFConcurrentRequestEnforcer)
        -- Using special value to indicate the client side connect failure
        self.meta.enforcer_response_code = 12  -- 0xc - onnect
        self:trigger_backoff()
        return nil, err
    end

    res, err = kwafc:full_request(kwaf_request_params)
    if not res then
        rlog(
                ngx.ERR,
                request_id,
                "Failed to send/read request from enforcer: ",
                err
        )
        metrics:increment(metrics.stream_metric_names.WAFEnforcerErrorRead)
        -- Using special value to indicate the client side read failure
        self.meta.enforcer_response_code = 10  -- 0xa - cknowledge
        self:trigger_backoff()
    else
        self.meta.enforcer_response_code = res.status
    end

    self.meta.enforcer_response_time = get_time() - enforcer_start_time
    metrics:decrement(metrics.stream_metric_names.WAFConcurrentRequestEnforcer)
    return res, err
end

_M.handle_kwaf_inspection = function(self, kwaf_connect_options, kwaf_request_params, shadow, chunk_size)
    local blocked = false
    local ok, err
    local kwafc
    local http_error_response = true
    kwafc, err = http.new(self.meta.request_id, self.config.flush_size, self.config.content_length_gate)
    if err then
        self:log(ngx.ERR, "Failed to create new HTTP object: ", err)
        return blocked, false, "handle_kwaf_inspection - http.new: " .. err, nil, http_error_response
    end

    err = kwafc:set_timeouts(self.config.enforcer_connect_time, self.config.enforcer_send_time, self.config.enforcer_read_time)
    if err then
        self:log(ngx.ERR, "Failed to set timeouts: ", err)
    end

    local co_kwafc_request
    if shadow then
        co_kwafc_request = ngx_thread_spawn(self.forward_request_to_enforcer, self, kwaf_connect_options, kwaf_request_params, shadow, kwafc)
        return blocked, true, nil, co_kwafc_request, http_error_response
    else
        local res
        res, err = self:forward_request_to_enforcer(kwaf_connect_options, kwaf_request_params, shadow, kwafc)
        if not res then
            self:log(ngx.ERR, "Failed to send request to KWAF: ", err)
            return blocked, false, "handle_kwaf_inspection - full_request error:" .. err, nil, http_error_response
        else
            if res.status == 403 then
                blocked = true
                http_error_response = false
                ok, err = kwafc:stream_proxy_response(res, chunk_size, kwaf_request_params, false)
                self:log(ngx.DEBUG, "Enforcer blocked the request: ", res.status)
                return blocked, ok, err, nil, http_error_response
            end
        end
    end
    return blocked, true, nil, nil, http_error_response
end

_M.set_waf_request_log = function(self)
    local spent_time = get_time() - self.meta.request_start_time

    ngx_var.edge_req_id = self.meta.request_id
    ngx_var.waf_request_status = self.meta.waf_request_status
    ngx_var.waf_request_time = spent_time
    ngx_var.enforcer_response_time = self.meta.enforcer_response_time
    ngx_var.enforcer_response_code = self.meta.enforcer_response_code
    local log_message = {
        -- Key name are purposely small to keep the log line size small.
        rid = self.meta.request_id,
        rst = self.meta.request_response_code,
        wrk = ngx.worker.pid(),
        wst = self.meta.waf_request_status,
        wrt = spent_time,
        ert = self.meta.enforcer_response_time,
        erc = self.meta.enforcer_response_code,
        hst = self.meta.host_name,
        fhs = self.meta.headers_size -- fhs - size of headers from front sandwich
    }
    metrics:capture_time(metrics.stream_metric_names.WAFRequestHandlingTime, spent_time)
    metrics:capture_time(metrics.stream_metric_names.WAFRequestHandlingCode, self.meta.waf_request_status)
    metrics:capture_time(metrics.stream_metric_names.WAFEnforcerHandlingTime, self.meta.enforcer_response_time)
    metrics:capture_time(metrics.stream_metric_names.WAFEnforcerHandlingCode, self.meta.enforcer_response_code)
    self:access_log(log_message)
    self:log(ngx.DEBUG, "Setting request data: ", elogger.dump_table(log_message))
end

_M.downstream_exit_with_error = function(self, status, err)
    if err then self:log(ngx.ERR, err) end
    local ret_status = tonumber(status) or 0

    self:set_waf_request_log()
    -- trigger backoff as we are seeing failure with WAF backend
    self:trigger_backoff()
    metrics:increment(metrics.stream_metric_names.WAFRequestFailure)
    metrics:decrement(metrics.stream_metric_names.WAFConcurrentRequestEdge)
    ngx_exit(ret_status)
end

_M.downstream_error_response = function(self, status, reason, err)
    local response_start_line = "HTTP/1.1 " .. tostring(status) .. " " .. reason .. "\r\nConnection: Closed\r\nContent-Length: 0\r\n"
    ngx.say(response_start_line) -- adds last \r\n to mark end of response
    local ok, flush_err = ngx.flush(true)
    if not ok then
        -- In case of failed request, flush will fail too. To avoid spamming, limit logging to debug mode.
        self:log(ngx.DEBUG,  "Failed to flush request before exit err: ", flush_err)
    end
    self:downstream_exit_with_error(ngx_OK, err)
end

_M.should_keepalive_connection = function(self, connection_header_value, http_version)
    local keepalive_connection = self.config.should_keepalive_downstream_conn
    if (http_version == "1.0") then
        keepalive_connection = false
    end
    if connection_header_value then
        if connection_header_value == "close" then
            keepalive_connection = false
        elseif connection_header_value == "keep-alive" then
            keepalive_connection = true
        end
    end
    return keepalive_connection
end

_M.set_stream_error_metadata = function(self, err_msg)
    for _, err_obj in ipairs(_M.KNOWN_UPSTREAM_ERR_MSG) do
        if string.find(err_msg, err_obj.msg) then
            metrics:increment(err_obj.metric)
            self.meta.waf_request_status = err_obj.code
            return
        end
    end
    metrics:increment(metrics.stream_metric_names.WAFDownstreamResponseError)
    self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_DOWNSTREAM_RESPONSE_ERROR
end
--- determines if the incoming request is a websockets upgrade request
--- by checking the request headers 'Connection' and 'Upgrade'
--- @param headers table? original request headers
--- @return boolean
local function is_websockets_request(headers)
	if headers[_WEBSOCKETS_UPG_HEADER.name] then
		if
			tostring(headers[_WEBSOCKETS_CONN_HEADER.name]):lower() == _WEBSOCKETS_CONN_HEADER.value
			and tostring(headers[_WEBSOCKETS_UPG_HEADER.name]):lower() == _WEBSOCKETS_UPG_HEADER.value
		then
			return true
		end
	end
	return false
end

--- for phase 1 support - replaces the Connection:Upgrade header with Connection:"" and
--- adds an x-kwaf header to state this was originally a websockets upgrade request
--- @param headers table? original request headers to be modified
local function replace_websockets_headers(headers)
	headers[_WEBSOCKETS_CONN_HEADER.name] = ""
	headers[_WEBSOCKETS_ALT_HEADER.name] = _WEBSOCKETS_ALT_HEADER.value
end
_M.http_transaction = function(self, downstream_sock, upstream_connect_options, kwaf_connect_options, shadow)
    local method, uri, version, start_line, err, ok
    self:reset_metadata()

    method, uri, version, start_line, err = http.receive_start_line(downstream_sock)
    if err then
        if err:match("closed$") then
            self:log(ngx.INFO, "Keepalive connection closed exiting thread: ", err)
            metrics:decrement(metrics.stream_metric_names.WAFConcurrentRequestEdge)
            ngx.exit(ngx.OK)
        else
            self:log(ngx.ERR, "Failed to read incoming request: ", err)
            metrics:increment(metrics.stream_metric_names.WAFDownstreamReadError)
            self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.DOWNSTREAM_SOCK_READ_FAILURE
            self:downstream_exit_with_error(self.config.inspection_fail_error_code, err)
        end
        -- Added for unit testing, in real world thread will exit
        return false
    end

    local downstream_headers
    metrics:increment(metrics.stream_metric_names.WAFRequestCount)
    downstream_headers, err = http.receive_headers(downstream_sock)
    if err then
        self:log(ngx.ERR, "Failed to parse request headers: ", err)
        if string.find(err, _M.KNOWN_DOWNSTREAM_ERR_MSG.CLIENT_CLOSE_REGEX_READ_ERROR.msg) then
            metrics:increment(metrics.stream_metric_names.WAFClientCloseRegexReadError)
            self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_DOWNSTREAM_REGEX_READ_ERROR
        else
            metrics:increment(metrics.stream_metric_names.WAFDownstreamParseError)
            self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.DOWNSTREAM_HEADER_READ_FAILURE
        end
        self:downstream_error_response(self.config.inspection_fail_error_code, self.config.inspection_fail_reason, err)
        return false
    end
    local is_websockets = is_websockets_request(downstream_headers)
    self:log(ngx.DEBUG, "Is it websocket? ==> ".. tostring(is_websockets))

    local downstream_content_length = tonumber(downstream_headers[standard_headers.content_length] or "0")
    self.meta.request_id = downstream_headers[standard_headers.request_id] or "id-header-missing"
    self.meta.host_name = downstream_headers[standard_headers.host] or "host-name-missing"
    self:log(ngx.INFO, "Successfully parsed downstream request headers for method: ", method)
    self:log(ngx.DEBUG, "Request URI: ", uri, " Request headers: ", elogger.dump_table(downstream_headers))

    local downstream_is_chunked = http.transfer_encoding_is_chunked(downstream_headers)
    if (downstream_content_length > 0) and downstream_is_chunked then
        self:log(ngx.ERR, "Failed to parse request content length: invalid chunk configuration")
        metrics:increment(metrics.stream_metric_names.WAFDownstreamInvalidRequest)
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.DOWNSTREAM_HEADER_CHUNK_INVALID
        self:downstream_error_response(
            self.config.inspection_fail_error_code,
            self.config.inspection_fail_reason,
            "downstream request has both Content-Length: " .. downstream_content_length .. " and Transfer-Encoding: chunked ")
        return false
    end

    if downstream_is_chunked then
        metrics:increment(metrics.stream_metric_names.WAFRequestTransferEncodingCount)
    end

    local downstream_keepalive_connection = self:should_keepalive_connection(downstream_headers[standard_headers.connection], version)

    local downstream_body_reader = http.get_body_reader(downstream_sock, downstream_headers, self.config.chunk_size, self.config.content_length_gate)
    if downstream_body_reader == nil then
        self:log(ngx.ERR, "Failed to read request body: nil body")
        metrics:increment(metrics.stream_metric_names.WAFDownstreamBodyError)
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.DOWNSTREAM_BODY_READ_FAILURE
        self:downstream_error_response(
            self.config.inspection_fail_error_code,
            self.config.inspection_fail_reason,
            "error getting downstream body reader")
        return false
    end

    -----kwaf section
    local new_kwaf_headers, kwaf_content_length
    new_kwaf_headers, kwaf_content_length = self:kwaf_headers(downstream_headers, downstream_content_length, downstream_is_chunked)
    if is_websockets then
        -- for phase 1 support - set content length to 0 (to avoid creating a body_reader)
        -- and remove 'upgrade' from connection header
        kwaf_content_length = 0
        replace_websockets_headers(new_kwaf_headers)
    end
    self:log(ngx.INFO, "UPSTREAM HEADER: ", new_kwaf_headers[standard_headers.upstream_cell])
    local splitter_ops = {
        reader = downstream_body_reader,
        max_chunk_size = self.config.chunk_size,
        kwaf_max_read_bytes = kwaf_content_length,
        kwaf_yield_time = self.config.splitter_kwaf_yield_time or 0,
        upstream_yield_time = self.config.splitter_upstream_yield_time or 0,
        shadow = shadow,
    }
    local sp = splitter.new(splitter_ops)

    --ovewrite http version when downstream listener will be configured with http version 1.0
    --version="1.1"
    local kwaf_request_params = {
        keepalive = true,
        keepalive_timeout = self.config.enforcer_keepalive_time,
        version = version,
        method = method,
        path = uri,
        body = sp:kwaf_reader(),
        headers = new_kwaf_headers,
    }

    local blocked, co_func, http_error_response
    if not self.config.enforcer_interaction_disable then
        blocked, ok, err, co_func, http_error_response = self:handle_kwaf_inspection(kwaf_connect_options, kwaf_request_params, shadow, self.config.chunk_size)
    else
        blocked = false
        ok = true
    end

    if blocked then -- blocked, no need to proceed
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_REQUEST_FORBIDDEN
        self:set_waf_request_log()
        metrics:increment(metrics.stream_metric_names.WAFRequestForbidden)
        metrics:decrement(metrics.stream_metric_names.WAFConcurrentRequestEdge)
        self:log(ngx.DEBUG, "Enforcer Forbidden Request")
        ngx_exit(ngx_OK)
        -- Added for unit testing, in real world thread will exit
        return false
    end

    if self.config.kwaf_fail_close and (not ok) then -- if there was any error and fail-close, report and stop
        local err_msg = "fail inspecting request and fail-close - error: " .. err
        metrics:increment(metrics.stream_metric_names.WAFRequestFailCloseDrop)
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_REQUEST_FAIL_CLOSE_DROP
        if http_error_response then
            err_msg = err_msg .. " http_error_response: " .. tostring(http_error_response)
            self:downstream_error_response(self.config.inspection_fail_error_code, self.config.inspection_fail_reason, err_msg)
        else
            self.downstream_exit_with_error(self.config.inspection_fail_error_code, err_msg)
        end
        return false
    end

    local upstreamc = http.new(self.meta.request_id, self.config.flush_size, self.config.content_length_gate)
    if self.config.debug then
        upstreamc.debug(true)
    end

    ok, err = upstreamc:connect(upstream_connect_options)
    if not ok then
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_UPSTREAM_CONNECT_ERROR
        self:downstream_error_response(self.config.inspection_fail_error_code, self.config.inspection_fail_reason, err)
        return false
    end
    -- ovewrite http version when downstream listener will be configured with http version 1.0
    --version="1.1"
    local upstream_request_params = {
        keepalive = true,
        keepalive_timeout = self.config.lua_keepalive_timeout,
        version = version,
        method = method,
        path = uri,
        body = sp:upstream_reader(),
        headers = downstream_headers,
    }

    local upstreamc_res
    upstreamc_res, err = upstreamc:request(upstream_request_params)
    if not upstreamc_res then
        self:log(ngx.ERR, "Failed to receive upstream response: ", err)
        metrics:increment(metrics.stream_metric_names.WAFUpstreamResponseError)
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.WAF_UPSTREAM_REQUEST_ERROR
        self:downstream_error_response(self.config.inspection_fail_error_code, self.config.inspection_fail_reason, err)
        return false
    end
    self.meta.request_response_code = upstreamc_res.status
    local do_close = not is_websockets
    ok, err = upstreamc:stream_proxy_response(upstreamc_res, self.config.chunk_size, upstream_request_params, do_close)
    if not ok then
        self:set_stream_error_metadata(err)
        self:downstream_exit_with_error(self.config.inspection_fail_error_code, err)
        return false
    end

    self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.SUCCESS
    self:set_waf_request_log()
    metrics:increment(metrics.stream_metric_names.WAFRequestSuccess)
	-- if upstream didn't response with 101 Switching protocols - return
    if upstreamc_res.status == _SWITCHING_PROTOCOLS_STATUS_CODE then
        -- Start proxy
        local tcp_opts = {
            max_recv_size = 8000,
            timeout = 30,
            close_wait_count = 10,
            close_wait_time = 3,
        }
        local tp = tcpproxy.new()
        -- tp:debug()
        local res = tp:proxy(downstream_sock, upstreamc.sock, tcp_opts)
        self:log(ngx.INFO,"downstream_keepalive_connection: ", downstream_keepalive_connection)
        -- need to investigate more i frequired to return false to break the http_transaction loop in websocket case
        return false
    end
    self:log(ngx.INFO, "log_filter http dowwnstream_keepalive_connection: ", downstream_keepalive_connection)
    return downstream_keepalive_connection
end

_M.init = function(opts)
    local log_level = ngx.INFO
    if opts.debug then
        log_level = ngx.DEBUG
    end

    local access_log_options = {
        debug = opts.debug,
        access_log_path = opts.access_log_path,
        access_flush_interval = opts.access_flush_interval,
        -- use default formatter for now
        access_log_size = opts.access_log_size,
        access_log_enable = opts.access_log_enable,
    }
    alogger.init(access_log_options)

    local handler_opts = {
        debug = opts.debug,
        backoff_lock_hold_time = opts.backoff_lock_hold_time,
        backoff_trigger_threshold = opts.backoff_trigger_threshold,
        enable_backoff_threshold = opts.enable_backoff_threshold
    }
    handler.init(handler_opts)
    
    metrics:init(true, false)

    -- set lua upstream connection backlog pool size to nil in case we receive a negative(invalid) value
    local lua_backlog_size
    if opts.lua_backlog and (opts.lua_backlog >= 0) then
        lua_backlog_size = opts.lua_backlog
    end

    _M.waf_config = {
        debug = opts.debug or false,
        min_log_level = log_level,
        kwaf_fail_close = not opts.fail_open,
        should_keepalive_downstream_conn = opts.should_keepalive_downstream_conn or false,
        chunk_size = opts.chunk_size,
        partial_header_name =  opts.partial_header_name or "x-envoy-auth-partial-body",
        original_content_length_header_name = opts.original_content_length_header_name or "x-enforcer-original-content-length",
        max_req_bytes = opts.max_req_bytes,
        lua_backlog = lua_backlog_size,
        flush_size = opts.flush_size or 0,

        lua_pool_size = opts.lua_pool_size,
        lua_keepalive_timeout = opts.lua_keepalive * 1000,  -- in milliseconds

        backoff_report_url = opts.backoff_url or "unix:/cfgs/rptc/waf/writer.sock",
        backoff_skip_codes = _M.parse_backoff_skip_codes(opts.backoff_skip_codes) or {},
        backoff_trigger_threshold = opts.backoff_trigger_threshold or 0,
        backoff_protect_mode = opts.backoff_protect_mode or false,

        enforcer_interaction_disable = opts.enforcer_interaction_disable or false,
        enforcer_service_address = opts.enforcer_service_address or "127.0.0.1",
        enforcer_service_port = opts.enforcer_service_port,
        enforcer_connect_time = opts.enforcer_request_connect_time,
        enforcer_send_time = opts.enforcer_request_send_time,
        enforcer_read_time = opts.enforcer_request_read_time,
        enforcer_keepalive_time = opts.enforcer_request_keepalive_time * 1000, -- in milliseconds
        enforcer_pool_size = opts.enforcer_request_pool_size,
        enforcer_backlog_size = opts.enforcer_request_backlog_size,

        inspection_fail_error_code = opts.inspection_fail_error_code,
        inspection_fail_reason = opts.inspection_fail_reason or "CustomNotAcceptable",

        access_log_path = opts.access_log_path or "/tmp/waf-stream-access.log",
        access_flush_interval = opts.access_flush_interval,
        access_log_size =  tonumber(opts.access_log_size) or 500000000,
        access_log_enable = opts.access_log_enable,

        content_length_gate = opts.waf_content_length_gate or false,

        splitter_kwaf_yield_time = opts.splitter_kwaf_yield_time or 0,
        splitter_upstream_yield_time = opts.splitter_upstream_yield_time or 0,
    }

    ngx.log(ngx.INFO, "Initializing KWAF module with: ", elogger.dump_table(_M.waf_config))
end

_M.perform_request_handling = function(self, lua_upstream_listener, shadow)
    local err, downstream_sock

    if not shadow then
        -- decide if to perform backoff in protect mode
        self.meta.backoff_enabled = self.waf_config.backoff_protect_mode
    end
    downstream_sock, err = ngx_req_socket(true)
    if not downstream_sock then
        metrics:increment(metrics.stream_metric_names.WAFDownstreamConnectError)
        self:log(ngx.ERR, "Failed to create downstream socket: ", err)
        self.meta.waf_request_status = _M.WAF_REQUEST_STATUS.DOWNSTREAM_SOCK_CONNECT_FAILURE
        self:downstream_exit_with_error(self.config.inspection_fail_error_code, err)
        -- Added for unit testing, in real world thread will exit
        return false
    end

    local kwaf_connect_options = {
        scheme = "http",
        host = self.config.enforcer_service_address,
        port = self.config.enforcer_service_port,
        pool = "kwaf-pool",
        pool_size = self.config.enforcer_pool_size, -- expicitely, defined in directive, options as per: https://github.com/openresty/lua-nginx-module#tcpsockconnect
        backlog = self.config.enforcer_backlog_size,
    }

    local upstream_connect_options
    if lua_upstream_listener:sub(1, 5) == "unix:" then
        upstream_connect_options = {
            host = lua_upstream_listener,
            -- Don't use connection pool name otherwise, request for different upstream listener backend.8443 and backend.9443 can be routed incorrectly.
            -- pool = "upstream-pool",
            pool_size = self.config.lua_pool_size, -- issue pool was nil before - defined in directive, options as per: https://github.com/openresty/lua-nginx-module#tcpsockconnect
            backlog = self.config.lua_backlog
        }
    else -- assume its only the tcp upstream listener port
        upstream_connect_options = {
            scheme = "http",
            host = "127.0.0.1",
            port = tonumber(lua_upstream_listener),
            -- Don't use connection pool name otherwise, request for different upstream listener backend.8443 and backend.9443 can be routed incorrectly.
            -- pool = "upstream-pool",
            pool_size = self.config.lua_pool_size, -- issue pool was nil before - defined in directive, options as per: https://github.com/openresty/lua-nginx-module#tcpsockconnect
            backlog = self.config.lua_backlog
        }
    end

    metrics:increment(metrics.stream_metric_names.WAFConcurrentRequestEdge)
    while self:http_transaction(downstream_sock, upstream_connect_options, kwaf_connect_options, shadow) do
    end
end

_M.new = function()
    local default_metadata = {
        request_id = "WORKER-"..ngx.worker.pid(),
        waf_request_status = _M.WAF_REQUEST_STATUS.UNDEFINED,
        request_response_code = 0,
        request_start_time = get_time(),
        enforcer_response_code = 0,
        enforcer_response_time = 0,
        backoff_triggered = false,
        backoff_enabled = true,
        host_name = "-",
        headers_size = 0,
    }
    return setmetatable({config=_M.waf_config, meta=default_metadata}, mt)
end

return _M
