--- This file handles the stream context metrics request from collectd
--- Whenever called it ignores the request and simply returns back the metrics
local _M = { VERSION = '0.1' }

_M.init = function()
    -- Truncated code
end

_M.provide_metrics_data = function() 
    local data = "Dummy"
    -- Create HTTP response for client
    ngx.say("HTTP/1.1 200 OK")
    ngx.say("Content-Type: application/json")
    -- Additional byte for new line in response from ngx.say
    ngx.say("Content-Length: ", #data + 1)
    ngx.say("Server: sfdcedge\r\n")
    ngx.say(data)
end

return _M
