-- Supports WAF request handling for a given connection
local streamer = require "waf.stream.kwaf_stream"

local _M = { VERSION = '0.1' }

_M.init = function(opts)
    streamer.init(opts)
end

_M.perform_request_handling = function(lua_upstream_listener, shadow)
    local connection_handler = streamer.new()
    connection_handler:perform_request_handling(lua_upstream_listener, shadow)
end

return _M