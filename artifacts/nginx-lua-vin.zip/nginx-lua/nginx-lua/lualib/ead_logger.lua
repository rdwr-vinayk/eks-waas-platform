local logger = { VERSION = '0.1' }

local logger_mt = {
    __index = logger
}

local LOG_ENUM = {}
LOG_ENUM["ngx.DEBUG"] = ngx.DEBUG
LOG_ENUM["ngx.ERR"] = ngx.ERR
LOG_ENUM["ngx.INFO"] = ngx.INFO
LOG_ENUM["ngx.WARN"] = ngx.WARN
LOG_ENUM["ngx.STDERR"] = ngx.STDERR
LOG_ENUM["ngx.EMERG"] = ngx.EMERG
LOG_ENUM["ngx.ALERT"] = ngx.ALERT
LOG_ENUM["ngx.CRIT"] = ngx.CRIT
LOG_ENUM["ngx.NOTICE"] = ngx.NOTICE

local default_log_level = ngx.DEBUG

logger.set_default_log_level = function(log_level)
    default_log_level = LOG_ENUM[log_level]
end

logger.new = function(module_name, max_allowed_level)
    ngx.log(ngx.DEBUG, "For module [", module_name, "] setting log filter level: ", max_allowed_level)
    return setmetatable(
        {
            name = module_name;
            level = max_allowed_level;
        },
        logger_mt)
end

function logger.get_request_id()
    return "id-not-available"
end

function logger.log(self, log_level, ...)
    logger.slog(self.name, log_level, self.level, logger.get_request_id(), ...)
end

function logger.hlog(mod_name, log_level, ...)
    local ok, rv = pcall(logger.get_request_id)
    local reqid = "n/a"
    if ok then
        reqid = rv
    end
    logger.slog(mod_name, log_level, default_log_level, reqid, ...)
end

-- for catchall block calls requiring resolve_certs
function logger.nlog(mod_name, log_level, sni, ...)
    if sni == nil then
        sni = "sni-not-available"
    end
    logger.slog(mod_name, log_level, default_log_level, sni, ...)
end

function logger.slog(name, log_level, max_allowed_level, request_id, ...)
    ngx.log(log_level, "[", name, "]:", request_id, ": ", ...)
end

function logger.dump_table(table)
    local function print_table(tbl, indent)
        indent = indent or " - "
        local tbl_str = ""
        for k, v in pairs(tbl) do
            if type(v) == "table" then
                tbl_str = tbl_str .. indent .. tostring(k) .. ":"
                print_table(v, indent .. "  ")
            else
                tbl_str = tbl_str .. indent .. tostring(k) .. ": " .. tostring(v)
            end
        end
        return tbl_str
    end
    return print_table(table)
end

return logger
