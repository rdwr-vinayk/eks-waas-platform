#!/usr/bin/env bash
cd "$(dirname "$0")"
set -eu



build(){
    mkdir -p sample-nginx-integration/files/openresty-lua/conf.d/ sample-nginx-integration/files/openresty-lua/lualib/
    cp conf.d/* sample-nginx-integration/files/openresty-lua/conf.d/
    cp -R lualib/* sample-nginx-integration/files/openresty-lua/lualib/
    cp nginx.conf sample-nginx-integration/files/openresty-lua/
}

build_install(){
    echo "install @$APP_NS with $MORE values "
    build
    cd ../
    helm upgrade -i waas-nginx-gw -n ${APP_NS} --create-namespace ../nginx-lua/sample-nginx-integration ${MORE} 2>&1
}
build_upgrade(){
    build_install
}
build_tls(){
    echo "create tls certificate"
    DIR="build/ssl"
    if [ ! -d "$DIR" ]; then
        mkdir -p $DIR
    fi
    # create self signed certificate
    openssl req -x509 -newkey rsa:2048 -keyout build/ssl/tls.key -out build/ssl/tls.crt -sha256 -days 365 -nodes -subj "/C=IL/ST=TL/L=TLV/O=RADWARE/OU=CTO/CN=${APP_NS}"
    chmod -R ugo+rw build/
}
delete(){
    helm delete -n $APP_NS waas-nginx-gw
}
exit_with_error() {
    usage
    exit 1
}
usage() {
    echo "Usage: $0 command APP_NS" 1>&2
    echo "    -i command to install openresty HELM chart"
    echo "    -u command to upgrade openresty HELM chart"
    echo "    -t command to create tls certificate for dev docker"
    echo "    -d command to delete openresty HELM chart"
    echo "    APP_NS OPENRESTY NAMESPACE or DOMAIN in case certificate creation"
}

while getopts "biutd" options; do
    case "${options}" in
        b)
            cmd="build"
            ;;
        i)
            cmd="install"
            ;;
        u)
            cmd="upgrade"
            ;;
        t)
            cmd="tls"
            ;;
        d)
            cmd="delete"
            ;;
        :)
            echo "Error: -${OPTARG} requires an argument."
            ;;
        *)
            exit_with_error
            ;;
    esac
done


# Check if any arguments were passed
if [ $OPTIND -eq 1 ]; then
    exit_with_error
fi

# Check if all arguments were passed
if [ $# -lt 2 ]; then
    exit_with_error
fi

FLAG=$1
shift
APP_NS=$1
shift
MORE=$@
echo " Flags=$FLAG APPNS=$APP_NS MORE=$MORE "
if [[ "$cmd" = "install" ]]; then
    echo "install"
    build_install
elif [[ "$cmd" = "upgrade" ]]; then
    echo "upgrade"
    build_upgrade
elif [[ "$cmd" = "tls" ]]; then
    echo "create tls certificate"
    build_tls
elif [[ "$cmd" = "delete" ]]; then
    echo "delete"
    delete
else
    echo "build"
    build
fi



