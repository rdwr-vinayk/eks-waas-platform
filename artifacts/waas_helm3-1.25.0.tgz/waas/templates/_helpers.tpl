{{/*
Helper template to get the appropriate address based on custom value or IPv6 support
Logagent requires different formatting for IPv6 addresses (enclosed in square brackets) while others can't handle that.
For that reason, two separate helper templates are created, usage is identical in both.
Usage: {{ include "getAddress" (dict "address" .Values.global.apiDiscovery.apiDiscoveryLogAddr/webddosLogAddr/statsdAddr "context" .) }}
*/}}
{{- define "getAddress" -}}
{{- if .address }}
{{- .address | quote }}
{{- else if .context.Values.global.ipv6Support }}
{{- "::1" }}
{{- else }}
{{- "127.0.0.1" }}
{{- end }}
{{- end }}

{{/*
Logagent specific helper template to get the appropriate address based on custom value or IPv6 support.
usage: {{ include "getLogagentAddress" (dict "address" .Values.global.apiDiscovery.apiDiscoveryLogAddr/webddosLogAddr/statsdAddr "context" .) }}
*/}}
{{- define "getLogagentAddress" -}}
{{- if .address }}
{{- .address | quote }}
{{- else if .context.Values.global.ipv6Support }}
{{- "[::1]" | quote }}
{{- else }}
{{- "127.0.0.1" | quote }}
{{- end }}
{{- end }}
