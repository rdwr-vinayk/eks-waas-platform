{{/*
volumes configuration for pods where
 one container (enforcer) writes logs
 and another (logagent) reads them
 and a third (log-rotate) rotates them
*/}}
{{- define "waas.logagent-volumes" }}
{{- if .Values.global.nats.enabled }}
- name: nats-users-secret-volume
  secret:
    secretName: waas-nats-users-secret
    items:
    - key: logagent_user
      path: logagent_user
    - key: logagent_password
      path: logagent_password
{{- end }}
- name: logs-volume
  emptyDir:
    {{- toYaml .Values.volumeLogs | nindent 4 }}
- name: logagent-config
  emptyDir:
    {{- toYaml .Values.logagent.logagentConfig | nindent 4 }}
{{/* logagent client TLS volumes */}}
{{- with .Values.tls.clients.logagent.logstash }}
  {{- if eq .enabled true -}}
    {{- with .volumes}}
      {{- toYaml . }}
    {{- end }}
  {{- end }}
{{- end }}
{{/* logagent NATS client TLS volumes */}}
{{- if or .Values.global.apiDiscovery.enabled .Values.global.webddos.enabled  }}
{{- with .Values.tls.clients.logagent.nats }}
  {{- if eq .enabled true -}}
    {{- with .volumes}}
      {{- toYaml . }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end -}}
{{- end }}
