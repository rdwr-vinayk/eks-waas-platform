{{/*
logagent container manifest
reads enforcer logs (security + access + recieving over grpc statsd_metrics) and sends over http(s) to logstash
if apiDiscovery is enabled, getting api_discovery log from enforcer over otel grpc and send it to nats service.
*/}}
{{ define "waas.logagent-container" }}
- name: logagent
  image: {{ include "waas.image.registry" . | coalesce .Values.containers.logagent.registry }}/waas-logagent{{ include "waas.image.version" . | coalesce .Values.containers.logagent.version }}
  imagePullPolicy: {{ .Values.global.image.pullPolicy }}
  env:
  - name: LS_HOST
    {{- if .Values.alternateLogstashHost }}
    value: {{ .Values.alternateLogstashHost | quote }}
    {{- else }}
    value: waas-logstash.{{ .Release.Namespace }}.svc
    {{- end }}
  - name: LS_PORT
    {{- if .Values.global.logstash.servicePort }}
    value: {{ .Values.global.logstash.servicePort | quote }}
    {{- else }}
    value: "2020"
    {{- end }}
    {{- if .Values.global.logaggregatorEnabled }} 
  - name: LOGAGGREGATOR_ENABLED
    value: {{ .Values.global.logaggregatorEnabled | quote }}
    {{- end }}
  {{- if or (eq .Values.global.apiDiscovery.enabled true) (eq .Values.global.webddos.enabled true) }}
  - name: API_DISCOVERY_LOG_ADDR
    value: {{ include "getLogagentAddress" (dict "address" .Values.global.apiDiscovery.apiDiscoveryLogAddr "context" .) }}  
  - name: API_DISCOVERY_LOG_GRPC_PORT
    value: {{ .Values.global.apiDiscovery.apiDiscoveryLogGRPCPort | default "4317" | quote }}
  - name: API_DISCOVERY_LOG_HTTP_PORT
    value: {{ .Values.global.apiDiscovery.apiDiscoveryLogHTTPPort | default "4318" | quote }}
  - name: WEBDDOS_LOG_ADDR
    value: {{ include "getLogagentAddress" (dict "address" .Values.global.webddos.webddosLogAddr "context" .) }}
  - name: WEBDDOS_LOG_GRPC_PORT
    value: {{ .Values.global.webddos.webddosLogGRPCPort | default "4319" | quote }}
  - name: WEBDDOS_LOG_HTTP_PORT
    value: {{ .Values.global.webddos.webddosLogHTTPPort | default "4320" | quote }}
  - name: NATS_ENABLED
    value: {{ .Values.global.nats.enabled | default "false" | quote }}
  - name: NATS_HOST
    {{- if .Values.alternateNatsHost }}
    value: {{ .Values.alternateNatsHost | quote }}
    {{- else }}
    value: {{ print "waas-nats." .Release.Namespace ".svc" | quote }}
    {{- end }}
  - name: NATS_PORT
    value: {{ .Values.global.nats.servicePort | default "4222" | quote }}
  {{- with .Values.tls.clients.logagent.nats }}
  - name: NATS_TLS
    {{- if .enabled }}
    value: "true"
  - name: NATS_TLS_VERIFY
    {{- if .verify }}
    # TODO - get ca/cert/key for nats client separately from logstash client config
    value: "true"
    {{- else }}
    value: "false"
    {{- end }}
    {{- else }}
    value: "false"
    {{- end }}
  {{- end }}
  - name: NATS_USERS_SECRET_DIR
    value: /logagent/users_secret
  {{- end }}
  - name: LOG_LEVEL
    value: info
  - name: FLUSH
    value: "1"
  - name: HTTP_PORT
    {{- if .Values.global.logagent.httpPort }}
    value: {{ .Values.global.logagent.httpPort | quote }}
    {{- else }}
    value: "2025"
    {{- end }}
  - name: LOGS_PATH
    value: "/logs"
  - name: MAX_BATCH_SIZE
    value: "1e+08"
  - name: MAX_BUF_EVENTS
    value: "10000"
  - name: HTTP_LISTEN
    {{- if .Values.global.ipv6Support }}
    value: "[::]"
    {{- else }}
    value: "0.0.0.0"
    {{- end }}
  - name: STATSD_ADDR
    value: {{ include "getLogagentAddress" (dict "address" .Values.statsdAddr "context" .) }}    
  - name: STATSD_PORT
    value: "{{ .Values.statsdPort | default "8125" }}"
{{- with .Values.tls.clients.logagent.logstash}}
  {{- if .enabled }}
  - name: TLS
    value: "On"
  - name: TLS_MTLS
    {{- if .clientAuth }}
    value: "On"
    {{- else }}
    value: "Off"
    {{- end }}
  - name: TLS_VERIFY
    {{- if .verify }}
    value: "On"
    {{- else }}
    value: "Off"
    {{- end }}
   {{- if ne .ca "" }}
  - name: TLS_CA_FILE
    value: {{ .ca }}
   {{- end }}
   {{- if ne .clientCertificate "" }}
  - name: TLS_CRT_FILE
    value: {{ .clientCertificate }}
   {{- end }}
   {{- if ne .clientKey "" }}
  - name: TLS_KEY_FILE
    value: {{ .clientKey }}
   {{- end }}
  - name: NATS_TLS_CA_FILE
    value: "/etc/logagent/ca/ca.crt"
  - name: NATS_TLS_CRT_FILE
    value: "/etc/logagent/client/tls.crt"
  - name: NATS_TLS_KEY_FILE
    value: "/etc/logagent/client/tls.key"
  {{- else }}
  - name: TLS
    value: "Off"
  {{- end}}
{{- end }}
  livenessProbe:
  {{- toYaml .Values.containers.logagent.livenessProbe | nindent 4 }}
  readinessProbe:
  {{- toYaml .Values.containers.logagent.readinessProbe | nindent 4 }}
  resources:
    {{- toYaml .Values.containers.logagent.resources | nindent 4 }}
  {{- with .Values.containers.logagent.securityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  volumeMounts:
{{- /* logagent client TLS mounts */}}
{{- with .Values.tls.clients.logagent }}
  {{- with .nats }}
    {{- if eq .enabled true -}}
      {{- with .mounts }}
        {{- toYaml . | nindent 2 }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- with .logstash }}
    {{- if eq .enabled true -}}
      {{- with .mounts }}
        {{- toYaml . | nindent 2 }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}
  - name: logs-volume
    mountPath: /logs
  - name: logagent-config
    mountPath: /logagent/cfg
{{- if .Values.global.nats.enabled }}
  - name: nats-users-secret-volume
    mountPath: /logagent/users_secret
    readOnly: true
{{- end }}
{{- end -}}
